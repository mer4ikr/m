<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Логин</title>
    <link rel="stylesheet" href="/styles/login.css">
</head>
<body>
    <h1>Логин</h1>
    <form action="login.php" method="post">
        <label for="login">Логин:</label>
        <input type="text" id="login" name="login" required>

        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Логин</button>
    </form>
    <div class="link">
    <a href="/registration.php">Нету аккаунта? Регистрация</a>
    </div>

    <?php
    require 'functions.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $login = $_POST['login'];
        $password = $_POST['password'];

        if (login_user($login, $password)) {
            echo "<p>Вход в систему прошел успешно. Добро пожаловать, $login!</p>";
        } else {
            echo "<p>Ошибка: Неверный логин или пароль</p>";
        }
    }
    ?>
</body>
</html>